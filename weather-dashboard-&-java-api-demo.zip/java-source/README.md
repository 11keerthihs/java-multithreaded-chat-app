# Java Weather Application

This is a complete Java implementation for consuming a REST API.

## Requirements
- Java 11 or higher (uses `java.net.http.HttpClient`)

## Project Structure
- `Main.java`: Entry point, handles user input and orchestration.
- `ApiService.java`: Handles HTTP requests asynchronously.
- `WeatherModel.java`: Data model for weather information.

## How to Run
1. Navigate to the `src` directory.
2. Compile the classes:
   ```bash
   javac com/weatherapp/Main.java com/weatherapp/service/ApiService.java com/weatherapp/model/WeatherModel.java
   ```
3. Run the application:
   ```bash
   java com.weatherapp.Main
   ```

## Note on JSON Parsing
In this demo, I used a simple string extraction method to avoid external dependencies. For production, it is highly recommended to use a library like:
- **Jackson**: `com.fasterxml.jackson.core`
- **Gson**: `com.google.code.gson`
- **org.json**: `org.json`
