package com.weatherapp;

import com.weatherapp.model.WeatherModel;
import com.weatherapp.service.ApiService;
import java.util.Scanner;

/**
 * Main entry point for the Weather Application.
 */
public class Main {
    // Note: In a real app, you'd use a library like org.json or Gson.
    // For this demo, we'll simulate parsing or use a simple regex approach 
    // to keep it runnable without external JARs in a basic environment.
    
    public static void main(String[] args) {
        ApiService apiService = new ApiService();
        Scanner scanner = new Scanner(System.in);

        System.out.println("=== Java Weather CLI ===");
        System.out.print("Enter city name: ");
        String city = scanner.nextLine();

        // Using Open-Meteo (Free, no key required)
        // We first need coordinates, but for simplicity, let's assume a fixed URL 
        // or show how to build the request.
        String url = "https://api.open-meteo.com/v1/forecast?latitude=52.52&longitude=13.41&current_weather=true";

        System.out.println("\nFetching data for " + city + " (Demo coordinates: Berlin)...");

        apiService.fetchData(url)
            .thenAccept(json -> {
                // Simple manual "parsing" for demo purposes
                // In production, use: JSONObject obj = new JSONObject(json);
                double temp = extractValue(json, "temperature");
                String condition = "Clear"; // Simplified
                int humidity = 65; // Simplified
                
                WeatherModel model = new WeatherModel(city, temp, humidity, condition);
                System.out.println("\n" + model.toString());
            })
            .exceptionally(ex -> {
                System.err.println("Error: " + ex.getMessage());
                return null;
            })
            .join(); // Wait for completion

        scanner.close();
    }

    private static double extractValue(String json, String key) {
        try {
            int index = json.indexOf("\"" + key + "\":");
            if (index == -1) return 0.0;
            int start = index + key.length() + 3;
            int end = json.indexOf(",", start);
            if (end == -1) end = json.indexOf("}", start);
            return Double.parseDouble(json.substring(start, end).trim());
        } catch (Exception e) {
            return 0.0;
        }
    }
}
