package com.weatherapp.model;

/**
 * Model class representing weather data.
 */
public class WeatherModel {
    private String cityName;
    private double temperature;
    private int humidity;
    private String condition;

    public WeatherModel(String cityName, double temperature, int humidity, String condition) {
        this.cityName = cityName;
        this.temperature = temperature;
        this.humidity = humidity;
        this.condition = condition;
    }

    // Getters and Setters
    public String getCityName() { return cityName; }
    public double getTemperature() { return temperature; }
    public int getHumidity() { return humidity; }
    public String getCondition() { return condition; }

    @Override
    public String toString() {
        return String.format(
            "Weather in %s:\n" +
            "------------------\n" +
            "Condition:   %s\n" +
            "Temperature: %.1f°C\n" +
            "Humidity:    %d%%\n",
            cityName, condition, temperature, humidity
        );
    }
}
