package com.weatherapp.util;

/**
 * Utility class for JSON parsing.
 * In a real-world scenario, you would use Jackson or Gson.
 */
public class JsonParser {
    /**
     * Extracts a numeric value from a simple JSON string.
     * @param json The JSON string.
     * @param key The key to look for.
     * @return The double value associated with the key.
     */
    public static double getDouble(String json, String key) {
        String search = "\"" + key + "\":";
        int index = json.indexOf(search);
        if (index == -1) return 0.0;
        
        int start = index + search.length();
        int end = json.indexOf(",", start);
        if (end == -1) end = json.indexOf("}", start);
        
        try {
            return Double.parseDouble(json.substring(start, end).trim());
        } catch (NumberFormatException e) {
            return 0.0;
        }
    }
}
