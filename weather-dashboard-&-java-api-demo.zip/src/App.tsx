import { useState, useEffect, type FormEvent } from 'react';
import { Search, Wind, Droplets, Thermometer, MapPin, Cloud, Sun, CloudRain, CloudLightning, Snowflake, Loader2 } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { format } from 'date-fns';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';

// Types for our weather data
interface WeatherData {
  city: string;
  temp: number;
  condition: string;
  humidity: number;
  windSpeed: number;
  daily: {
    date: string;
    maxTemp: number;
    minTemp: number;
    conditionCode: number;
  }[];
}

const WEATHER_CODES: Record<number, { label: string; icon: any }> = {
  0: { label: 'Clear sky', icon: Sun },
  1: { label: 'Mainly clear', icon: Sun },
  2: { label: 'Partly cloudy', icon: Cloud },
  3: { label: 'Overcast', icon: Cloud },
  45: { label: 'Fog', icon: Cloud },
  48: { label: 'Depositing rime fog', icon: Cloud },
  51: { label: 'Light drizzle', icon: CloudRain },
  53: { label: 'Moderate drizzle', icon: CloudRain },
  55: { label: 'Dense drizzle', icon: CloudRain },
  61: { label: 'Slight rain', icon: CloudRain },
  63: { label: 'Moderate rain', icon: CloudRain },
  65: { label: 'Heavy rain', icon: CloudRain },
  71: { label: 'Slight snow', icon: Snowflake },
  73: { label: 'Moderate snow', icon: Snowflake },
  75: { label: 'Heavy snow', icon: Snowflake },
  80: { label: 'Slight rain showers', icon: CloudRain },
  81: { label: 'Moderate rain showers', icon: CloudRain },
  82: { label: 'Violent rain showers', icon: CloudRain },
  95: { label: 'Thunderstorm', icon: CloudLightning },
};

export default function App() {
  const [search, setSearch] = useState('London');
  const [weather, setWeather] = useState<WeatherData | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const fetchWeather = async (cityName: string) => {
    setLoading(true);
    setError(null);
    try {
      // 1. Geocoding
      const geoRes = await fetch(`https://geocoding-api.open-meteo.com/v1/search?name=${cityName}&count=1&language=en&format=json`);
      const geoData = await geoRes.json();
      
      if (!geoData.results || geoData.results.length === 0) {
        throw new Error('City not found');
      }

      const { latitude, longitude, name, country } = geoData.results[0];

      // 2. Weather Data
      const weatherRes = await fetch(`https://api.open-meteo.com/v1/forecast?latitude=${latitude}&longitude=${longitude}&current_weather=true&daily=weathercode,temperature_2m_max,temperature_2m_min&timezone=auto`);
      const weatherData = await weatherRes.json();

      const current = weatherData.current_weather;
      const daily = weatherData.daily;

      setWeather({
        city: `${name}, ${country}`,
        temp: Math.round(current.temperature),
        condition: WEATHER_CODES[current.weathercode]?.label || 'Unknown',
        humidity: 65, // Open-Meteo current_weather doesn't include humidity by default in simple call
        windSpeed: current.windspeed,
        daily: daily.time.map((time: string, i: number) => ({
          date: time,
          maxTemp: Math.round(daily.temperature_2m_max[i]),
          minTemp: Math.round(daily.temperature_2m_min[i]),
          conditionCode: daily.weathercode[i],
        })),
      });
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to fetch weather');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchWeather('London');
  }, []);

  const handleSearch = (e: FormEvent) => {
    e.preventDefault();
    if (search.trim()) {
      fetchWeather(search);
    }
  };

  const WeatherIcon = weather ? (WEATHER_CODES[weather.daily[0].conditionCode]?.icon || Cloud) : Cloud;

  return (
    <div className="min-h-screen bg-[#0a0502] text-white font-sans selection:bg-orange-500/30">
      {/* Atmospheric Background */}
      <div className="fixed inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-[-10%] left-[-10%] w-[40%] h-[40%] bg-orange-600/20 blur-[120px] rounded-full animate-pulse" />
        <div className="absolute bottom-[-10%] right-[-10%] w-[50%] h-[50%] bg-blue-900/20 blur-[120px] rounded-full" />
      </div>

      <main className="relative z-10 max-w-4xl mx-auto px-6 py-12">
        {/* Header & Search */}
        <header className="flex flex-col md:flex-row md:items-center justify-between gap-6 mb-12">
          <div>
            <h1 className="text-4xl font-light tracking-tight mb-2">
              Sky<span className="font-semibold text-orange-500">Cast</span>
            </h1>
            <p className="text-white/50 text-sm font-mono uppercase tracking-widest">Weather Intelligence</p>
          </div>

          <form onSubmit={handleSearch} className="relative group">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-white/30 group-focus-within:text-orange-500 transition-colors" />
            <Input
              type="text"
              placeholder="Search city..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="pl-10 bg-white/5 border-white/10 focus:border-orange-500/50 focus:ring-orange-500/20 w-full md:w-64 transition-all"
            />
          </form>
        </header>

        {error && (
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            className="bg-red-500/10 border border-red-500/20 text-red-400 p-4 rounded-xl mb-8 flex items-center gap-3"
          >
            <Loader2 className="w-4 h-4 animate-spin" />
            {error}
          </motion.div>
        )}

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Main Card */}
          <div className="lg:col-span-2">
            <AnimatePresence mode="wait">
              {loading ? (
                <Card className="bg-white/5 border-white/10 backdrop-blur-xl h-[400px]">
                  <CardContent className="p-8 space-y-6">
                    <Skeleton className="h-8 w-48 bg-white/5" />
                    <div className="flex items-center gap-8">
                      <Skeleton className="h-32 w-32 rounded-full bg-white/5" />
                      <div className="space-y-4">
                        <Skeleton className="h-16 w-32 bg-white/5" />
                        <Skeleton className="h-6 w-24 bg-white/5" />
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ) : weather && (
                <motion.div
                  key={weather.city}
                  initial={{ opacity: 0, scale: 0.95 }}
                  animate={{ opacity: 1, scale: 1 }}
                  exit={{ opacity: 0, scale: 0.95 }}
                  transition={{ duration: 0.4, ease: "easeOut" }}
                >
                  <Card className="bg-white/5 border-white/10 backdrop-blur-xl overflow-hidden group">
                    <div className="absolute inset-0 bg-gradient-to-br from-orange-500/5 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-700" />
                    <CardContent className="p-8 relative">
                      <div className="flex items-center gap-2 text-white/60 mb-8">
                        <MapPin className="w-4 h-4" />
                        <span className="text-sm font-medium">{weather.city}</span>
                        <Badge variant="outline" className="ml-auto border-white/10 text-white/40 font-mono text-[10px]">
                          {format(new Date(), 'HH:mm')}
                        </Badge>
                      </div>

                      <div className="flex flex-col md:flex-row items-center md:items-end justify-between gap-8">
                        <div className="flex items-center gap-8">
                          <div className="relative">
                            <div className="absolute inset-0 bg-orange-500/20 blur-3xl rounded-full" />
                            <WeatherIcon className="w-32 h-32 relative text-orange-500" strokeWidth={1.5} />
                          </div>
                          <div>
                            <div className="text-8xl font-light tracking-tighter mb-2">
                              {weather.temp}°
                            </div>
                            <div className="text-xl text-white/80 font-medium">{weather.condition}</div>
                          </div>
                        </div>

                        <div className="grid grid-cols-2 gap-8 w-full md:w-auto">
                          <div className="space-y-1">
                            <div className="flex items-center gap-2 text-white/40 text-xs uppercase tracking-widest">
                              <Wind className="w-3 h-3" /> Wind
                            </div>
                            <div className="text-xl font-light">{weather.windSpeed} <span className="text-xs text-white/40">km/h</span></div>
                          </div>
                          <div className="space-y-1">
                            <div className="flex items-center gap-2 text-white/40 text-xs uppercase tracking-widest">
                              <Droplets className="w-3 h-3" /> Humidity
                            </div>
                            <div className="text-xl font-light">{weather.humidity}%</div>
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </motion.div>
              )}
            </AnimatePresence>
          </div>

          {/* Forecast Side Panel */}
          <div className="space-y-6">
            <h3 className="text-xs font-mono uppercase tracking-[0.2em] text-white/40 px-2">7-Day Forecast</h3>
            <div className="space-y-3">
              {loading ? (
                Array.from({ length: 7 }).map((_, i) => (
                  <Skeleton key={i} className="h-16 w-full bg-white/5 rounded-xl" />
                ))
              ) : weather?.daily.map((day, i) => {
                const DayIcon = WEATHER_CODES[day.conditionCode]?.icon || Cloud;
                return (
                  <motion.div
                    key={day.date}
                    initial={{ opacity: 0, x: 20 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: i * 0.05 }}
                    className="flex items-center justify-between p-4 bg-white/5 border border-white/5 rounded-xl hover:bg-white/10 transition-colors"
                  >
                    <div className="flex items-center gap-4">
                      <div className="text-sm font-medium w-10">
                        {i === 0 ? 'Today' : format(new Date(day.date), 'EEE')}
                      </div>
                      <DayIcon className="w-5 h-5 text-white/60" />
                    </div>
                    <div className="flex items-center gap-4">
                      <span className="text-sm font-medium">{day.maxTemp}°</span>
                      <span className="text-sm text-white/30">{day.minTemp}°</span>
                    </div>
                  </motion.div>
                );
              })}
            </div>
          </div>
        </div>

        {/* Java Reference Section */}
        <section className="mt-24 pt-12 border-t border-white/10">
          <div className="flex items-center justify-between mb-8">
            <div>
              <h2 className="text-2xl font-light mb-2">Java Implementation</h2>
              <p className="text-white/40 text-sm">A complete reference for building this in Java.</p>
            </div>
            <div className="text-xs font-mono uppercase tracking-widest text-orange-500">
              Source in /java-source/
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card className="bg-white/5 border-white/10 backdrop-blur-sm">
              <CardHeader>
                <CardTitle className="text-sm font-mono text-white/60">ApiService.java</CardTitle>
              </CardHeader>
              <CardContent>
                <pre className="text-[10px] text-white/40 overflow-hidden">
                  {`public CompletableFuture<String> fetchData(String url) {
    HttpRequest request = HttpRequest.newBuilder()
            .uri(URI.create(url))
            .GET()
            .build();
    return httpClient.sendAsync(request, ...);
}`}
                </pre>
              </CardContent>
            </Card>
            <Card className="bg-white/5 border-white/10 backdrop-blur-sm">
              <CardHeader>
                <CardTitle className="text-sm font-mono text-white/60">WeatherModel.java</CardTitle>
              </CardHeader>
              <CardContent>
                <pre className="text-[10px] text-white/40 overflow-hidden">
                  {`public class WeatherModel {
    private String cityName;
    private double temperature;
    // ... getters and setters
}`}
                </pre>
              </CardContent>
            </Card>
          </div>
        </section>
      </main>

      <footer className="relative z-10 py-12 text-center border-t border-white/5 mt-12">
        <p className="text-white/20 text-[10px] uppercase tracking-[0.4em]">
          Built with React & Java Reference • 2026
        </p>
      </footer>
    </div>
  );
}
